-- Generated with DurtyClothTool

fx_version 'cerulean'
game { 'gta5' }

files {
  'mp_m_freemode_01_mp_m_urbanedge_pack.meta',
  'stream/pedalternatevariations.meta'
}

data_file 'SHOP_PED_APPAREL_META_FILE' 'mp_m_freemode_01_mp_m_urbanedge_pack.meta'
data_file 'ALTERNATE_VARIATIONS_FILE' 'stream/pedalternatevariations.meta'